from jobs.read_data import read_parquet_data
from jobs.write import write_csv


def city_wise_data():
    df = read_parquet_data("./output/extracted_data/")

    group_by_city = df.groupby("city") \
        .count() \
        .orderBy("count", ascending=False)

    write_csv(group_by_city, "./output/city_wise_split")

if __name__ == '__main__':
    city_wise_data()
