from matplotlib import pyplot as plt
from pyspark.sql import Window
from pyspark.sql.functions import col, mean, percent_rank

from config.spark_config import spark
from jobs.read_data import read_parquet_data
from jobs.write import write_csv

currency_data = [
    ("london", 1.27),
    ("tokyo", 0.0067),
    ("bangkok", 0.028),
    ("mexico-city", 0.059),
    ("toronto", 0.74),
    ("barcelona", 1.09),
    ("berlin", 1.09),
    ("austin", 1.0),
    ("amsterdam", 1.09),
    ("chicago", 1.0),
    ("new-york-city", 1.0)
]

def properties_price_difference():
    df = read_parquet_data("./output/extracted_data/listing")
    properties_price_per_acc = (
        df
        .withColumn("accommodates", col("accommodates").try_cast("integer"))
        .withColumn("average", col("price") / col("accommodates"))
        .dropna()
        .groupby("city")
        .agg(mean("average").alias("average_price"))
    )

    currency_df = spark.createDataFrame(
        currency_data,
        ["city", "fx_rate"]
    )

    final_df = properties_price_per_acc \
        .join(currency_df, on="city", how="left") \
        .withColumn("avg_price_usd", col("average_price") * col("fx_rate")) \
        .drop("fx_rate", "average_price") \
        .orderBy("avg_price_usd", ascending = False)


    write_csv(final_df, "./output/properties_price_difference")

def luxury_properties():
    window_spec = Window.partitionBy("city").orderBy("average")

    df = read_parquet_data("./output/extracted_data/listing")

    luxury_accommodations = (
        df
        .withColumn("accommodates", col("accommodates").try_cast("integer"))
        .withColumn("average", col("price") / col("accommodates"))
        .withColumn("PercentRank", percent_rank().over(window_spec))
        .dropna()
        .filter(col("PercentRank") > 0.8)
        .select("city", "price", "accommodates", "PercentRank")
    )

    write_csv(luxury_accommodations, "./output/accommodations/luxury/", partition_by="city")

def budget_properties():
    window_spec = Window.partitionBy("city").orderBy("average")

    df = read_parquet_data("./output/extracted_data/listing")

    budget_accommodations = (
        df
        .withColumn("accommodates", col("accommodates").try_cast("integer"))
        .withColumn("average", col("price") / col("accommodates"))
        .withColumn("PercentRank", percent_rank().over(window_spec))
        .dropna()
        .filter(col("PercentRank") < 0.4)
        .select("city", "price", "accommodates")
    )

    write_csv(budget_accommodations, "./output/accommodations/budget/", partition_by="city")

if __name__ == '__main__':
    # properties_price_difference()
    luxury_properties()
    # budget_properties()